﻿using TesteSinq.Models;

namespace TesteSinq.Services
{
    public class CidadeService : ICidadeService
    {

        private readonly List<Cidade> _cidades = new List<Cidade>();

        public IEnumerable<Cidade> GetAllCidades()
        {
            //Vai no banco

            return _cidades;
        }
        public void AddCidade(Cidade cidade)
        {
            throw new NotImplementedException();
        }

        public void DeleteCidade(int id)
        {
            throw new NotImplementedException();
        }

        public Cidade GetCidadeById(int id)
        {
            throw new NotImplementedException();
        }

        public void UpdateCidade(Cidade cidade)
        {
            throw new NotImplementedException();
        }
    }
}
