﻿namespace TesteSinq.Services
{
    public interface IProduct
    {
        string Operate();
    }
}
