﻿using TesteSinq.Models;

namespace TesteSinq.Services
{
    public interface ICidadeService
    {
        IEnumerable<Cidade> GetAllCidades();
        Cidade GetCidadeById(int id);
        void AddCidade(Cidade cidade);
        void UpdateCidade(Cidade cidade);
        void DeleteCidade(int id);
    }
}
