﻿using Microsoft.AspNetCore.Mvc;
using TesteSinq.Services;

namespace TesteSinq.Controllers
{
    public class CidadesController : Controller
    {
        private readonly ICidadeService _cidadeService;

        public CidadesController(ICidadeService cidadeService)
        {
            _cidadeService = cidadeService;
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
