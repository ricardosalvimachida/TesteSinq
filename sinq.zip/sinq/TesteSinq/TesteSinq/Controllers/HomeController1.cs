﻿using Microsoft.AspNetCore.Mvc;
using TesteSinq.Factory;
using TesteSinq.Services;

namespace TesteSinq.Controllers
{
    public class HomeController1 : Controller
    {
        private readonly ProductFactory _factory;

        public HomeController1(ProductFactory factory)
        {
            _factory = factory;
        }

        public IActionResult Index()
        {
            // Criando produtos usando o método de fábrica
            IProduct product1 = _factory.CreateProduct("Product1");
            IProduct product2 = _factory.CreateProduct("Product2");

            // Passando os produtos para a view
            ViewBag.Product1 = product1.Operate();
            ViewBag.Product2 = product2.Operate();

            return View();
        }
    }

}
