﻿using System.ComponentModel.DataAnnotations;

namespace TesteSinq.Models
{
    public class User
    {
        [Required(ErrorMessage ="User is Required")]
        public string UserName { get; set; }

        [EmailAddress(ErrorMessage ="Email Inválido")]
        [Required(ErrorMessage = "Email is Required")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is Required")]
        [StringLength(14, MinimumLength = 8, ErrorMessage ="A senha é obrigatória")]
        public string Password { get; set; }
    }
}
