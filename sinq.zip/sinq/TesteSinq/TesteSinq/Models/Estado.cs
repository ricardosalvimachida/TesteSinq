﻿namespace TesteSinq.Models
{
    public class Estado
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
