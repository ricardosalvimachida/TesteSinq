﻿using TesteSinq.Services;

namespace TesteSinq.Models
{
    public class Produtos
    {
    }
    public class Produto1 : IProduct
    {
        public string Operate()
        {
            return "Produto1 operando";
        }
    }
    public class Produto2 : IProduct
    {
        public string Operate()
        {
            return "Produto2 operando";
        }
    }

}
