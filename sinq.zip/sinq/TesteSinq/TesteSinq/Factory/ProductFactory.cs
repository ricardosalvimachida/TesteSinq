﻿using TesteSinq.Models;
using TesteSinq.Services;

namespace TesteSinq.Factory
{
    public class ProductFactory
    {
        public IProduct CreateProduct(string type)
        {
            switch (type)
            {
                case "Product1":
                    return new Produto1();
                case "Product2":
                    return new Produto2();
                default:
                    throw new ArgumentException("Tipo de produto desconhecido");
            }
        }
    }
}
